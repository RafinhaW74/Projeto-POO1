//Rafael Munhoz Castro
//RA: 2564580
public class Cliente extends Pessoa{
    //método construtor
    public Cliente(){
    }
}
