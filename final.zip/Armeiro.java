//Rafael Munhoz Castro
//RA: 2564580
public class Armeiro extends Pessoa{
    //método construtor
    public Armeiro(){
    }
}
