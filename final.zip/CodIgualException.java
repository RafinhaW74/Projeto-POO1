//Rafael Munhoz Castro
//RA: 2564580
public class CodIgualException extends Exception{
	
}
